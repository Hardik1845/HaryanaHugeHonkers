from turtle import Turtle, Screen
import random
y=0
all_turtles = []
COLOR = ["red","green","blue","yellow","orange"]
screen = Screen()
screen.setup(800,600)
user_input = screen.textinput("Make a bet","Choose color")
winner = ""
for i in range(5):
    tim = Turtle()
    tim.color(COLOR[i])
    tim.shape("turtle")
    tim.penup()
    tim.goto(-380,y)
    y+=40
    tim.penup()
    all_turtles.append(tim)
game_is_on = True

while game_is_on:
    for turtle in all_turtles:
        turtle.forward(random.randint(0,30))
        if turtle.xcor() >380:
            game_is_on = False
            winner = turtle.pencolor()

if winner == user_input.lower():
    print("You won")
else:
    print("You lose")

print(f"The winner is {winner}")


screen.exitonclick()