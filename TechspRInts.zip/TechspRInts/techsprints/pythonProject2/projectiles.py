from turtle import Turtle

class BossBullets:
    def __init__(self):
        self.bullets = []
        self.bullet_speed = 25

    def generate_bullets(self, posx1, posy1, posx2, posy2):
        bullet1 = Turtle("square")
        bullet1.shapesize(stretch_len=2, stretch_wid=0.5)
        bullet1.setheading(270)
        bullet1.color("yellow")
        bullet1.penup()
        bullet1.goto(x=posx1, y=posy1)

        bullet2 = Turtle("square")
        bullet2.setheading(270)
        bullet2.shapesize(stretch_len=2, stretch_wid=0.5)
        bullet2.color("yellow")
        bullet2.penup()
        bullet2.goto(x=posx2, y=posy2)

        self.bullets.append(bullet1)
        self.bullets.append(bullet2)

    def move_bullets(self):
        for bullet in self.bullets:
            bullet.forward(self.bullet_speed)

class HeroBullet:
    def __init__(self):
        self.bullets = []
        self.bullet_speed = 15

    def generate_bullets(self, posx1, posy1):
        bullet1 = Turtle("square")
        bullet1.shapesize(stretch_len=2, stretch_wid=0.5)
        bullet1.setheading(90)
        bullet1.color("red")
        bullet1.penup()
        bullet1.goto(x=posx1, y=posy1)
        self.bullets.append(bullet1)

    def move_bullets(self):
        for bullet in self.bullets:
            bullet.forward(self.bullet_speed)
