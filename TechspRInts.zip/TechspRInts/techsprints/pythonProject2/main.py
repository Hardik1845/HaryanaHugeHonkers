from turtle import *
import time
from projectiles import BossBullets, HeroBullet
# Setting up the window

screen = Screen()
screen.setup(width=500, height=600)
screen.title("Planes")
screen.listen()
screen.tracer(0)

# Setting up sky
screen.register_shape("sky.gif")
sky = Turtle()
sky.shape("sky.gif")

# setting up boss plane
screen.register_shape("bossplane.gif")
boss_plane = Turtle()
boss_plane.shape("bossplane.gif")
boss_plane.penup()
boss_plane.goto(x=0, y=250)
boss_bullets = BossBullets()


def move_boss_plane():
    if boss_plane.xcor() == 180:
        boss_plane.setheading(180)
    elif boss_plane.xcor() == -180:
        boss_plane.setheading(0)
    boss_plane.forward(20)


# Setting up hero
screen.register_shape("hero.gif")
hero_plane = Turtle("hero.gif")
hero_plane.penup()
hero_plane.goto(x=0, y=-240)
hero_bullets = HeroBullet()


def move_left():
    hero_plane.setheading(180)
    hero_plane.forward(10)


def move_right():
    hero_plane.setheading(0)
    hero_plane.forward(10)


screen.onkeypress(fun=move_left, key="a")
screen.onkeypress(fun=move_right, key="d")

shooting_time_for_boss = 0
shooting_time_for_hero = 0

game_is_on = True
boss_bullets.generate_bullets(boss_plane.xcor() - 60, boss_plane.ycor() - 80, boss_plane.xcor() + 60,
                              boss_plane.ycor() - 80)

boss_health = 50
health_display = Turtle()
health_display.penup()
health_display.goto(x=-220, y=240)
health_display.hideturtle()
health_display.write(arg=f"Boss Health: {boss_health}", align="left", font=("Courier", 24, "normal"))



while game_is_on:
    time.sleep(0.1)
    move_boss_plane()
    if shooting_time_for_boss == 5:
        boss_bullets.generate_bullets(boss_plane.xcor() - 60, boss_plane.ycor() -80, boss_plane.xcor() + 60, boss_plane.ycor() -80)
        shooting_time_for_boss = 0

    if shooting_time_for_hero == 12:
        hero_bullets.generate_bullets(hero_plane.xcor(), hero_plane.ycor() +10)
        shooting_time_for_hero = 0

    for bullet in hero_bullets.bullets:
        if bullet.distance(boss_plane) < 30:
            bullet.hideturtle()
            boss_health -= 5
            health_display.clear()
            health_display.write(arg=f"Boss Health: {boss_health}", align="left", font=("Courier", 24, "normal"))
            if boss_health == 0:
                game_is_on = False
                health_display.goto(0, 0)
                health_display.write(arg="YOU WIN!", align="center", font=("Courier", 24, "normal"))
                break

    for bullet in boss_bullets.bullets:
        if bullet.distance(hero_plane) < 32:
            game_is_on = False
            health_display.goto(0, 0)
            health_display.write(arg="YOU LOST!", align="center", font=("Courier", 24, "normal"))

    boss_bullets.move_bullets()
    hero_bullets.move_bullets()
    shooting_time_for_boss += 1
    shooting_time_for_hero += 1
    screen.update()













screen.exitonclick()
