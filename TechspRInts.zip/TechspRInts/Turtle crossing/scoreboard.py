from turtle import Turtle
FONT = ("Courier",24,"normal")
class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("turtle")
        self.level_count = 1
        self.penup()
        self.goto(-270,235)

        self.write(f"Level:{self.level_count}", False, "Left",FONT)
        self.hideturtle()

    def game_over(self):
        self.goto(0,0)
        self.write("Game Over",False,"Center",FONT)

    def update_level(self):
        self.goto(0, 0)
        self.write("You win", False, "Center", FONT)
