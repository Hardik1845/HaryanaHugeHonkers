from turtle import Turtle
import random
X_COR = 280
MOVING_DISTANCE = 20
class Car(Turtle):
    def __init__(self):
        super().__init__()
        self.speed = MOVING_DISTANCE
        self.cars = []


    def create_car(self):

        random_number = random.randint(1, 6)
        if random_number == 1 or random_number==2:
            new_car = Turtle()
            r = random.randint(0, 255)
            g = random.randint(0, 255)
            b = random.randint(0, 255)
            new_car.shape("square")
            new_car.penup()
            new_car.shapesize(1, 2, None)
            new_car.goto(X_COR,random.randint(-280,280))
            new_car.color((r,g,b))


            self.cars.append(new_car)

    def move_car(self):
        for car in self.cars:
            car.backward(MOVING_DISTANCE)

    def increase_level(self):
        self.speed+=10