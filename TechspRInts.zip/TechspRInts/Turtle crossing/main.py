import turtle
import time
from player import Player
from car_manager import Car
from scoreboard import Scoreboard

turtle.colormode(255)
screen = turtle.Screen()
screen.tracer(0)
screen.listen()

screen.setup(600,600)
player = Player()
screen.onkey(player.go_up,"Up")
cars = Car()
scoreboard = Scoreboard()

game_is_on = True

while game_is_on:
    time.sleep(0.1)
    cars.create_car()
    cars.move_car()

    for car in cars.cars:
        if player.distance(car) <25:
            scoreboard.game_over()
            game_is_on = False
        if player.ycor()>280:
            scoreboard.update_level()
            game_is_on = False



    screen.update()




screen.exitonclick()